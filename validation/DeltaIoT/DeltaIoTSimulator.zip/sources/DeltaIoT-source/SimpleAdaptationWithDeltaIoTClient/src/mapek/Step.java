package mapek;

public enum Step {
	CHANGE_POWER,
	CHANGE_DIST;
}
