package deltaiot;

public class Main {

	public static void main(String [ ] args) {
		DeltaIoTSimulator setup = new DeltaIoTSimulator();
		setup.run();
	}
	
}
