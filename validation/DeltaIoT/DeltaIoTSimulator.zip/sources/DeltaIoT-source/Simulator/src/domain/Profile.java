package domain;

public interface Profile<T> {

	public T get(int runNumber);
	
}
