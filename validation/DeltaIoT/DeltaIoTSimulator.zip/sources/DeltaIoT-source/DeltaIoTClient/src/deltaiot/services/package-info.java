@javax.xml.bind.annotation.XmlSchema(namespace = "http://services.deltaiot/")
package deltaiot.services;
